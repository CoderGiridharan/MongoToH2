package com.samco;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MongoWithH2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
