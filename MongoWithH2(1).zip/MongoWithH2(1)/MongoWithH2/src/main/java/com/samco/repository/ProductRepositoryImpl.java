package com.samco.repository;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.BeanPropertyRowMapper;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.stereotype.Repository;

import com.samco.model.ProductH2;

@Repository
public class ProductRepositoryImpl {
	
	
	@Autowired
	JdbcTemplate jdbcTemplate;
	
	public int save(ProductH2 product) {
		return jdbcTemplate.update("INSERT INTO PRODUCT(ID,PRODUCTNAME,PRODUCTTYPE)VALUES(?,?,?)",
				new Object[] {product.getId(),product.getProductname(),product.getProducttype()});
	}
	
	public List<ProductH2> findAll(){
		return jdbcTemplate.query("SELECT * FROM PRODUCT", BeanPropertyRowMapper.newInstance(ProductH2.class));
	}
	
	
}
