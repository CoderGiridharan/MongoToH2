package com.samco.model;

import javax.persistence.Id;

import org.springframework.data.mongodb.core.mapping.Document;

@Document(collection = "Product")
public class Product {

	@Id
	private int id;
	private String productname;
	private String producttype;

	public Product() {
		super();
	}

	public Product(int id, String productname, String producttype) {
		super();
		this.id = id;
		this.productname = productname;
		this.producttype = producttype;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	@Override
	public String toString() {
		return "Product [id=" + id + ", productname=" + productname + ", producttype=" + producttype + "]";
	}
	
	

}
