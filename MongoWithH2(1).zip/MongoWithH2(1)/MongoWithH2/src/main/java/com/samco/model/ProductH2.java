package com.samco.model;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "product")
public class ProductH2 {

	@Id
	private int id;
	private String productname;
	private String producttype;

	public ProductH2() {
		super();
	}

	public ProductH2(int id, String productname, String producttype) {
		super();
		this.id = id;
		this.productname = productname;
		this.producttype = producttype;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getProductname() {
		return productname;
	}

	public void setProductname(String productname) {
		this.productname = productname;
	}

	public String getProducttype() {
		return producttype;
	}

	public void setProducttype(String producttype) {
		this.producttype = producttype;
	}

	@Override
	public String toString() {
		return "ProductH2 [id=" + id + ", productname=" + productname + ", producttype=" + producttype + "]";
	}

}
