package com.samco;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableAsync;

import com.samco.model.Product;
import com.samco.model.ProductH2;
import com.samco.repository.ProductRepository;
import com.samco.repository.ProductRepositoryImpl;

@SpringBootApplication
@EnableAsync
public class MongoWithH2Application implements CommandLineRunner {
	private final static Logger logger = LoggerFactory.getLogger(MongoWithH2Application.class);

	public static void main(String[] args) {
		SpringApplication.run(MongoWithH2Application.class, args);

		logger.info("this is a info message");
		logger.warn("this is a warn message");
		logger.error("this is a error message");
	}
	
	@Autowired
	ProductRepository productRepository;
	
	@Autowired
	ProductRepositoryImpl productRepositoryImpl;

	
	public void run(String... args) throws Exception {
		List<Product> employees = productRepository.findAll();
		Map<Integer, Product> emp = new HashMap<Integer, Product>();
		for(Product input:employees) {
			emp.put(input.getId(), input);
			ProductH2 empl = new ProductH2();
			empl.setId(input.getId());
			empl.setProductname(input.getProductname());
			empl.setProducttype(input.getProducttype());
			productRepositoryImpl.save(empl);
			System.out.println(empl);
		}
	}

}
